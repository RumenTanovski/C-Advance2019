﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person personFirst = new Person();
            Person personSecond = new Person();
            Person personThrid = new Person();

            personFirst.Name = "Pesho";
            personFirst.Age = 20;

            personSecond.Name = "Gosho";
            personSecond.Age = 18;

            personThrid.Name = "Stamat";
            personThrid.Age = 43;
            Console.WriteLine($"Name: {personFirst.Name}, age:{personFirst.Age}");

        }
    }
}
